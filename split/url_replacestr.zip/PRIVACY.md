## Privacy

1. Information Collected
   This plugin does not collect any information. The content of the TXT file is processed in memory.
2. How Information is Used
   The text content is adjusted in memory.
3. Information Sharing and Disclosure
   No information will be shared with third parties.
4. Information Storage and Security
   The storage location is the position specified by the Dify backend.
