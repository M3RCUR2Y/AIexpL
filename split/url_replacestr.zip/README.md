## url_replace

**Author:** lfenghx
**Version:** 0.0.1
**Type:** tool

### Description

这是一个 dify 插件，实现把 txt 文档中的 url 批量转换，你可以自行指定 url 前缀后缀
示例效果：
url1，url2，url3
【我是前缀】url1.【我是后缀】，【我是前缀】url2.【我是后缀】，【我是前缀】url3.【我是后缀】

This is a Dify plugin that enables batch conversion of URLs in a TXT document. You can specify the URL prefix and suffix on your own.
Example effect:
url1, url2, url3
[My prefix]url1.[My suffix], [My prefix]url2.[My suffix], [My prefix]url3.[My suffix]
