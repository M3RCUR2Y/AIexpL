from collections.abc import Generator
from typing import Any
import re

from dify_plugin import File, Tool
from dify_plugin.entities.tool import ToolInvokeMessage

class UrlReplaceTool(Tool):
    def _invoke(self, tool_parameters: dict[str, Any]) -> Generator[ToolInvokeMessage]:
        content = tool_parameters.get("content")  # 接收字符串内容
        prefix = tool_parameters.get("prefix")
        suffix = tool_parameters.get("suffix")
        
        try:
            # 验证内容是否为空
            if not content or not isinstance(content, str):
                yield self.create_text_message("输入内容无效")
                return
                
            if not content.strip():
                yield self.create_text_message("输入内容为空")
                return
                
            # 执行URL替换
            pattern = re.compile(r'url(\d+)')
            new_content = pattern.sub(
                lambda m: f"{prefix}url{m.group(1)}.{suffix}", 
                content
            )
            
            # 返回处理后的文件
            yield self.create_blob_message(
                blob=new_content.encode('utf-8'),
                meta={
                    "mime_type": "text/plain",
                    "file_name": "【url批量替换】.txt"  # 固定文件名
                }
            )
            
        except Exception as e:
            yield self.create_text_message(f"处理错误: {str(e)}")