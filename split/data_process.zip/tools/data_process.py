from collections.abc import Generator
from typing import Any
import time
import json  # 新增导入

from dify_plugin import Tool
from dify_plugin.entities.tool import ToolInvokeMessage
from dify_plugin.entities.model.llm import LLMModelConfig
from dify_plugin.entities.model.message import SystemPromptMessage, UserPromptMessage

class DataProcessTool(Tool):
    def _invoke(self, tool_parameters: dict[str, Any]) -> Generator[ToolInvokeMessage]:
        context = tool_parameters.get("context")
        userrequire = tool_parameters.get("userrequire")
        model_info = tool_parameters.get("model")

        # 记录开始时间
        start_time = time.time()
        
        # 直接处理整个文本，不再分块
        processed = self._process_with_llm(
            context,  # 直接传入完整文本
            userrequire,
            model_info,
        )
        
        # 计算处理时间
        process_time = round(time.time() - start_time, 2)  # 保留两位小数
        
        # 构造包含更多信息的返回字典
        result_dict = {
            "num": len(processed.encode('utf-8')),  # 改为计算大模型输出的字节数
            "time": process_time,  # 处理时间(秒)
            "result": processed  # 大模型输出结果
        }

        # 使用create_text_message返回处理结果
        yield self.create_text_message(json.dumps(result_dict, ensure_ascii=False))

    # 移除 _chunk_text 方法

    def _process_with_llm(self, text_chunk: str, userrequire: str, model_info: dict,) -> str:
        """调用大模型处理文本"""
        prompt = f"""你是一个文档分段大师，请严格按以下规则给文档分段：
1. 你需要理解全文，将文档内容按大主题，小主题进行划分，每个大主题对应一个父段，每个父段可以有多个子段
2. 你只进行分段处理，不允许改动原文内容
2. 父段说明：同一类内容都需要归到一个父段中，父段的主题要大，要独立，只要是同一个主题的内容都可以放到一个父段中。需在其开头插入"##\n父段：[xxxx]"标识，xxx内容自己提炼，要求符合此父段的核心思想，不超过20个字，若内容中已存在##，你需要判断是否符合父段要求，若符合则补全总结即可，不需要再加额外的##，若不符合则去除##。
3. 子段说明：在父段内部，你需要通过语义分析划分子段，子段之间的内容重点不一样，用\n分隔，若文章中已经有\n分割的内容，你需要判断分割的是否正确，若两段内容语义相近，你需要将其合并，去掉\n，若符合子段要求则不处理，特别是文本中已有序号标识的子段，请严格遵守原有分段，不需要再加额外的\n。
4. 用户额外要求：{userrequire}
5. 输出示例：
##
父段：[父段1内容总结.....]
子段内容示意...
子段内容示意...
子段内容示意...
##
父段：[父段2内容总结.....]
子段内容示意...
子段内容示意...
子段内容示意...

注：父段与父段，子段与子段，父段与子段之间不需要有空行

当前需要处理的文本：
{text_chunk}"""

        response = self.session.model.llm.invoke(
            model_config=LLMModelConfig(
                provider=model_info.get('provider'),
                model=model_info.get('model'),
                mode=model_info.get('mode'),
                completion_params=model_info.get('completion_params'),
            ),
            prompt_messages=[
                SystemPromptMessage(content="你是一个专业的文档处理助手"),
                UserPromptMessage(content=prompt)
            ],
            stream=False
        )
        
        return response.message.content